import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Film, LayoutDashboard, LogOut, Sparkles, User } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { trpc } from "@/lib/trpc";

export default function NavBar() {
  const { user, isAuthenticated, loading } = useAuth();
  const [location] = useLocation();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { window.location.href = "/"; },
  });

  const navLinks = [
    { href: "/generate", label: "Create", icon: Sparkles },
    { href: "/dashboard", label: "My Videos", icon: LayoutDashboard },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-background/80 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[oklch(0.82_0.18_196)] to-[oklch(0.55_0.22_290)] shadow-lg group-hover:shadow-[0_0_20px_oklch(0.82_0.18_196/0.4)] transition-shadow duration-300">
            <Film className="h-4 w-4 text-black" />
          </div>
          <span className="font-bold text-lg tracking-tight" style={{ fontFamily: "Syne, sans-serif" }}>
            <span className="gradient-text">Manifest</span>
            <span className="text-foreground/70 font-normal"> AI</span>
          </span>
        </Link>

        {/* Nav links */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href}>
              <Button
                variant="ghost"
                size="sm"
                className={`gap-2 text-sm font-medium transition-colors ${
                  location === href
                    ? "text-[oklch(0.82_0.18_196)] bg-[oklch(0.82_0.18_196/0.08)]"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Button>
            </Link>
          ))}
        </nav>

        {/* Auth */}
        <div className="flex items-center gap-3">
          {loading ? (
            <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
          ) : isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 border border-white/10 hover:border-[oklch(0.82_0.18_196/0.4)] transition-colors">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-gradient-to-br from-[oklch(0.82_0.18_196)] to-[oklch(0.55_0.22_290)] text-black text-xs font-bold">
                      {user.name?.charAt(0).toUpperCase() ?? <User className="h-4 w-4" />}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52 bg-card border-white/10">
                <div className="px-3 py-2">
                  <p className="text-sm font-medium text-foreground">{user.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                </div>
                <DropdownMenuSeparator className="bg-white/5" />
                <DropdownMenuItem asChild>
                  <Link href="/dashboard" className="cursor-pointer gap-2 flex items-center">
                    <LayoutDashboard className="h-4 w-4" /> My Videos
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-white/5" />
                <DropdownMenuItem
                  onClick={() => logoutMutation.mutate()}
                  className="text-red-400 focus:text-red-400 cursor-pointer gap-2"
                >
                  <LogOut className="h-4 w-4" /> Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <a href={getLoginUrl()}>
              <Button
                size="sm"
                className="manifest-btn text-sm px-4 py-2 h-9"
              >
                Sign In
              </Button>
            </a>
          )}
        </div>
      </div>
    </header>
  );
}
