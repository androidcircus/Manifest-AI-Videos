import { useAuth } from "@/_core/hooks/useAuth";
import NavBar from "@/components/NavBar";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  CheckCircle2,
  Circle,
  Clock,
  Film,
  Loader2,
  AlertCircle,
  FileText,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useState } from "react";
import { Link, useParams } from "wouter";

const STAGES = ["Analyzing", "Scripting", "Designing", "Generating", "Audio", "Finalizing"] as const;
type Stage = (typeof STAGES)[number];

const STAGE_ICONS: Record<Stage, string> = {
  Analyzing:  "🔍",
  Scripting:  "✍️",
  Designing:  "🎨",
  Generating: "🎬",
  Audio:      "🎵",
  Finalizing: "✨",
};

const STAGE_DESCRIPTIONS: Record<Stage, string> = {
  Analyzing:  "Parsing your story prompt and extracting key narrative elements, themes, and characters.",
  Scripting:  "Generating a full screenplay with acts, scenes, dialogue, and shot descriptions.",
  Designing:  "Creating visual style guides, color palettes, and cinematography plans for each scene.",
  Generating: "Rendering video frames and sequences using the AI generation pipeline.",
  Audio:      "Composing background score, sound effects, and mixing the audio track.",
  Finalizing: "Encoding, color grading, and packaging the final video output.",
};

const STATUS_CONFIG = {
  queued:     { label: "Queued",     color: "bg-white/10 text-muted-foreground" },
  processing: { label: "Processing", color: "bg-[oklch(0.82_0.18_196/0.15)] text-[oklch(0.82_0.18_196)]" },
  completed:  { label: "Complete",   color: "bg-green-500/15 text-green-400" },
  failed:     { label: "Failed",     color: "bg-red-500/15 text-red-400" },
};

const STYLE_EMOJI: Record<string, string> = {
  cinematic:   "🎬",
  documentary: "📽️",
  animation:   "✨",
  "sci-fi":    "🚀",
  fantasy:     "🧙",
  noir:        "🌑",
  thriller:    "⚡",
};

function ScriptPlanViewer({ scriptPlan }: { scriptPlan: string | null | undefined }) {
  const [expanded, setExpanded] = useState(false);
  if (!scriptPlan) return null;

  let parsed: any = null;
  try { parsed = JSON.parse(scriptPlan); } catch { return null; }

  return (
    <div className="glass-card p-6 space-y-4">
      <button
        onClick={() => setExpanded((v) => !v)}
        className="flex w-full items-center justify-between text-left"
      >
        <div className="flex items-center gap-2 font-semibold text-[oklch(0.82_0.18_196)]">
          <FileText className="h-5 w-5" />
          AI-Generated Script Plan
        </div>
        {expanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
      </button>

      {expanded && (
        <div className="space-y-5 text-sm border-t border-white/5 pt-4">
          {parsed.title && (
            <div>
              <div className="text-xs text-muted-foreground mb-1">Title</div>
              <div className="text-lg font-bold text-foreground" style={{ fontFamily: "Syne, sans-serif" }}>{parsed.title}</div>
            </div>
          )}
          {parsed.logline && (
            <div>
              <div className="text-xs text-muted-foreground mb-1">Logline</div>
              <div className="text-foreground/80 italic leading-relaxed">"{parsed.logline}"</div>
            </div>
          )}
          {parsed.productionNotes && (
            <div>
              <div className="text-xs text-muted-foreground mb-2">Production Notes</div>
              <div className="grid grid-cols-2 gap-3 p-4 rounded-xl bg-white/3">
                {Object.entries(parsed.productionNotes).map(([k, v]) => (
                  <div key={k}>
                    <div className="text-xs text-muted-foreground capitalize mb-0.5">{k.replace(/([A-Z])/g, " $1").trim()}</div>
                    <div className="text-sm text-foreground/80">{String(v)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {parsed.acts?.map((act: any) => (
            <div key={act.actNumber} className="border-t border-white/5 pt-4">
              <div className="font-semibold text-foreground mb-3" style={{ fontFamily: "Syne, sans-serif" }}>
                Act {act.actNumber}: {act.title}
                <span className="text-muted-foreground font-normal text-sm ml-2">({act.duration})</span>
              </div>
              <div className="space-y-3">
                {act.scenes?.map((scene: any) => (
                  <div key={scene.sceneNumber} className="p-3 rounded-xl bg-white/3 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-[oklch(0.82_0.18_196)]">Scene {scene.sceneNumber}</span>
                      <span className="text-xs text-muted-foreground">— {scene.location} ({scene.timeOfDay})</span>
                    </div>
                    <div className="text-sm text-foreground/80 leading-relaxed">{scene.description}</div>
                    {scene.shotType && (
                      <div className="text-xs text-muted-foreground">📷 {scene.shotType}</div>
                    )}
                    {scene.mood && (
                      <div className="text-xs text-muted-foreground">🎭 Mood: {scene.mood}</div>
                    )}
                    {scene.dialogue && (
                      <div className="text-xs text-foreground/60 italic border-l-2 border-[oklch(0.82_0.18_196/0.3)] pl-2 mt-1">
                        "{scene.dialogue}"
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function JobDetail() {
  const { id } = useParams<{ id: string }>();
  const jobId = parseInt(id ?? "0", 10);
  const { isAuthenticated } = useAuth();

  const { data: job, isLoading } = trpc.video.getStatus.useQuery(
    { jobId },
    {
      enabled: isAuthenticated && !isNaN(jobId) && jobId > 0,
      refetchInterval: (query) => {
        const data = query.state.data;
        if (!data) return false;
        if (data.status === "completed" || data.status === "failed") return false;
        return 2000;
      },
    }
  );

  const currentStageIdx = STAGES.findIndex((s) => s === job?.currentStage);
  const isComplete = job?.status === "completed";
  const isFailed = job?.status === "failed";
  const cfg = STATUS_CONFIG[job?.status as keyof typeof STATUS_CONFIG] ?? STATUS_CONFIG.queued;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.82_0.18_196)]" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <NavBar />
        <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4">
          <AlertCircle className="h-16 w-16 text-red-400 mb-6 opacity-60" />
          <h2 className="text-2xl font-bold mb-3">Job Not Found</h2>
          <p className="text-muted-foreground mb-8">This video job doesn't exist or you don't have access to it.</p>
          <Link href="/dashboard">
            <Button variant="outline" className="border-white/15">Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <NavBar />

      <div className="pointer-events-none fixed inset-0 overflow-hidden -z-10">
        <div className="absolute top-0 left-1/4 w-[600px] h-[400px] rounded-full bg-[oklch(0.82_0.18_196/0.05)] blur-[120px]" />
      </div>

      <div className="container pt-28 pb-16">
        <div className="max-w-4xl mx-auto">
          {/* Back */}
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground mb-6 -ml-2 gap-1.5">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>

          {/* Header */}
          <div className="flex items-start justify-between gap-4 mb-8">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-[oklch(0.82_0.18_196)] to-[oklch(0.55_0.22_290)] flex items-center justify-center text-2xl shadow-lg">
                {STYLE_EMOJI[job.id?.toString() ?? ""] ?? "🎬"}
              </div>
              <div>
                <h1 className="text-2xl font-bold" style={{ fontFamily: "Syne, sans-serif" }}>
                  Video Job #{job.id}
                </h1>
                <div className="text-sm text-muted-foreground">
                  {new Date(job.createdAt).toLocaleString()}
                </div>
              </div>
            </div>
            <Badge variant="secondary" className={`text-sm border-0 ${cfg.color} ${job.status === "processing" ? "animate-pulse" : ""}`}>
              {cfg.label}
            </Badge>
          </div>

          <div className="grid lg:grid-cols-5 gap-6">
            {/* Left: Details */}
            <div className="lg:col-span-3 space-y-5">
              {/* Prompt */}
              <div className="glass-card p-6">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Story Prompt</div>
                <p className="text-foreground/90 leading-relaxed">{job.prompt}</p>
              </div>

              {/* Script plan */}
              <ScriptPlanViewer scriptPlan={job.scriptPlan} />

              {/* Error */}
              {isFailed && job.errorMessage && (
                <div className="glass-card p-5 border border-red-500/20">
                  <div className="flex items-center gap-2 text-red-400 mb-2">
                    <AlertCircle className="h-4 w-4" />
                    <span className="font-semibold text-sm">Generation Failed</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{job.errorMessage}</p>
                  <Link href="/generate" className="mt-3 inline-block">
                    <Button size="sm" className="manifest-btn text-xs mt-3">Try Again</Button>
                  </Link>
                </div>
              )}

              {/* Completion */}
              {isComplete && (
                <div className="glass-card p-5 border border-[oklch(0.55_0.22_290/0.3)]">
                  <div className="flex items-center gap-2 text-green-400 mb-2">
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="font-semibold">Video Generation Complete</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Completed {job.completedAt ? new Date(job.completedAt).toLocaleString() : ""}
                  </p>
                </div>
              )}
            </div>

            {/* Right: Pipeline */}
            <div className="lg:col-span-2 space-y-5">
              {/* Progress */}
              <div className="glass-card p-6 space-y-5">
                <h3 className="text-sm font-semibold text-foreground" style={{ fontFamily: "Syne, sans-serif" }}>
                  Pipeline Progress
                </h3>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{job.currentStage ?? "Initializing"}</span>
                    <span>{Math.round(job.progress ?? 0)}%</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-white/5 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${job.progress ?? 0}%`,
                        background: isComplete
                          ? "oklch(0.55 0.22 290)"
                          : "linear-gradient(90deg, oklch(0.82 0.18 196), oklch(0.55 0.22 290))",
                      }}
                    />
                  </div>
                </div>

                {/* Stage list */}
                <div className="space-y-3">
                  {STAGES.map((stage, i) => {
                    const isDone = isComplete || i < currentStageIdx;
                    const isActive = !isComplete && i === currentStageIdx;

                    return (
                      <div key={stage} className="flex items-start gap-3">
                        <div className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs transition-all ${
                          isDone
                            ? "bg-[oklch(0.55_0.22_290)] text-white"
                            : isActive
                            ? "bg-[oklch(0.82_0.18_196)] text-black pulse-glow"
                            : "bg-white/5 text-white/20"
                        }`}>
                          {isDone ? <CheckCircle2 className="h-3.5 w-3.5" /> : isActive ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Circle className="h-3.5 w-3.5" />}
                        </div>
                        <div>
                          <div className={`text-sm font-medium ${isDone ? "text-[oklch(0.55_0.22_290)]" : isActive ? "text-[oklch(0.82_0.18_196)]" : "text-white/25"}`}>
                            {STAGE_ICONS[stage]} {stage}
                          </div>
                          {isActive && (
                            <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                              {STAGE_DESCRIPTIONS[stage]}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Metadata */}
              <div className="glass-card p-5 space-y-3">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Job Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Job ID</span>
                    <span className="text-foreground font-mono">#{job.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status</span>
                    <span className="text-foreground capitalize">{job.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created</span>
                    <span className="text-foreground">{new Date(job.createdAt).toLocaleDateString()}</span>
                  </div>
                  {job.completedAt && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Completed</span>
                      <span className="text-foreground">{new Date(job.completedAt).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
