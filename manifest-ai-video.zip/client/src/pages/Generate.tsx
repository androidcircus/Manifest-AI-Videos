import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import NavBar from "@/components/NavBar";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import {
  CheckCircle2,
  Circle,
  Clock,
  Film,
  Loader2,
  Wand2,
  AlertCircle,
  Sparkles,
  FileText,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useState, useEffect, useCallback } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

const STAGES = ["Analyzing", "Scripting", "Designing", "Generating", "Audio", "Finalizing"] as const;
type Stage = (typeof STAGES)[number];

const STAGE_ICONS: Record<Stage, string> = {
  Analyzing:  "🔍",
  Scripting:  "✍️",
  Designing:  "🎨",
  Generating: "🎬",
  Audio:      "🎵",
  Finalizing: "✨",
};

const STYLES = [
  { value: "cinematic",   label: "Cinematic",   emoji: "🎬" },
  { value: "documentary", label: "Documentary", emoji: "📽️" },
  { value: "animation",   label: "Animation",   emoji: "✨" },
  { value: "sci-fi",      label: "Sci-Fi",      emoji: "🚀" },
  { value: "fantasy",     label: "Fantasy",     emoji: "🧙" },
  { value: "noir",        label: "Noir",        emoji: "🌑" },
  { value: "thriller",    label: "Thriller",    emoji: "⚡" },
] as const;

type StyleValue = (typeof STYLES)[number]["value"];

function StageIndicator({ currentStage, progress, status }: {
  currentStage: string | null | undefined;
  progress: number;
  status: string;
}) {
  const currentIdx = STAGES.findIndex((s) => s === currentStage);
  const isComplete = status === "completed";
  const isFailed = status === "failed";

  return (
    <div className="space-y-3">
      {STAGES.map((stage, i) => {
        const isDone = isComplete || i < currentIdx;
        const isActive = !isComplete && i === currentIdx;
        const isPending = !isComplete && i > currentIdx;

        return (
          <div key={stage} className="flex items-center gap-3">
            {/* Icon */}
            <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm transition-all duration-500 ${
              isDone
                ? "bg-[oklch(0.55_0.22_290)] text-white"
                : isActive
                ? "bg-[oklch(0.82_0.18_196)] text-black pulse-glow"
                : "bg-white/5 text-white/30"
            }`}>
              {isDone ? <CheckCircle2 className="h-4 w-4" /> : isActive ? <Loader2 className="h-4 w-4 animate-spin" /> : <Circle className="h-4 w-4" />}
            </div>

            {/* Label */}
            <div className="flex-1">
              <div className={`text-sm font-medium transition-colors ${
                isDone ? "text-[oklch(0.55_0.22_290)]" : isActive ? "text-[oklch(0.82_0.18_196)]" : "text-white/30"
              }`}>
                {STAGE_ICONS[stage as Stage]} {stage}
              </div>
            </div>

            {/* Status badge */}
            {isDone && <Badge variant="secondary" className="text-xs bg-[oklch(0.55_0.22_290/0.15)] text-[oklch(0.55_0.22_290)] border-0">Done</Badge>}
            {isActive && <Badge variant="secondary" className="text-xs bg-[oklch(0.82_0.18_196/0.15)] text-[oklch(0.82_0.18_196)] border-0 animate-pulse">Running</Badge>}
          </div>
        );
      })}

      {isFailed && (
        <div className="flex items-center gap-2 text-red-400 text-sm mt-2">
          <AlertCircle className="h-4 w-4" />
          Generation failed. Please try again.
        </div>
      )}
    </div>
  );
}

function ScriptViewer({ scriptPlan }: { scriptPlan: string | null | undefined }) {
  const [expanded, setExpanded] = useState(false);
  if (!scriptPlan) return null;

  let parsed: any = null;
  try { parsed = JSON.parse(scriptPlan); } catch { return null; }

  return (
    <div className="glass-card p-5 space-y-4">
      <button
        onClick={() => setExpanded((v) => !v)}
        className="flex w-full items-center justify-between text-left"
      >
        <div className="flex items-center gap-2 text-sm font-semibold text-[oklch(0.82_0.18_196)]">
          <FileText className="h-4 w-4" />
          AI-Generated Script Plan
        </div>
        {expanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
      </button>

      {expanded && (
        <div className="space-y-4 text-sm">
          {parsed.title && (
            <div>
              <span className="text-muted-foreground">Title: </span>
              <span className="text-foreground font-medium">{parsed.title}</span>
            </div>
          )}
          {parsed.logline && (
            <div>
              <span className="text-muted-foreground">Logline: </span>
              <span className="text-foreground/80 italic">"{parsed.logline}"</span>
            </div>
          )}
          {parsed.productionNotes && (
            <div className="grid grid-cols-2 gap-2 p-3 rounded-lg bg-white/3">
              {Object.entries(parsed.productionNotes).map(([k, v]) => (
                <div key={k}>
                  <div className="text-xs text-muted-foreground capitalize">{k}</div>
                  <div className="text-xs text-foreground/80">{String(v)}</div>
                </div>
              ))}
            </div>
          )}
          {parsed.acts?.map((act: any) => (
            <div key={act.actNumber} className="border-t border-white/5 pt-3">
              <div className="font-medium text-foreground mb-2">Act {act.actNumber}: {act.title} <span className="text-muted-foreground font-normal">({act.duration})</span></div>
              <div className="space-y-2">
                {act.scenes?.slice(0, 3).map((scene: any) => (
                  <div key={scene.sceneNumber} className="p-2 rounded bg-white/3 text-xs">
                    <div className="text-[oklch(0.82_0.18_196)] mb-1">Scene {scene.sceneNumber} — {scene.location} ({scene.timeOfDay})</div>
                    <div className="text-foreground/70">{scene.description}</div>
                    {scene.shotType && <div className="text-muted-foreground mt-1">📷 {scene.shotType}</div>}
                  </div>
                ))}
                {act.scenes?.length > 3 && (
                  <div className="text-xs text-muted-foreground">+{act.scenes.length - 3} more scenes...</div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Generate() {
  const { isAuthenticated, loading: authLoading } = useAuth();

  const [prompt, setPrompt] = useState("");
  const [duration, setDuration] = useState(5);
  const [style, setStyle] = useState<StyleValue>("cinematic");
  const [activeJobId, setActiveJobId] = useState<number | null>(null);
  const [pollingEnabled, setPollingEnabled] = useState(false);

  const createJob = trpc.video.create.useMutation({
    onSuccess: (data) => {
      setActiveJobId(data.jobId);
      setPollingEnabled(true);
      toast.success("Video generation started!");
    },
    onError: (err) => {
      toast.error(err.message || "Failed to start generation");
    },
  });

  const jobStatus = trpc.video.getStatus.useQuery(
    { jobId: activeJobId! },
    {
      enabled: pollingEnabled && activeJobId !== null,
      refetchInterval: (query) => {
        const data = query.state.data;
        if (!data) return 2000;
        if (data.status === "completed" || data.status === "failed") return false;
        return 2000;
      },
    }
  );

  useEffect(() => {
    if (jobStatus.data?.status === "completed") {
      setPollingEnabled(false);
      toast.success("Your video is ready!");
    } else if (jobStatus.data?.status === "failed") {
      setPollingEnabled(false);
      toast.error("Generation failed. Please try again.");
    }
  }, [jobStatus.data?.status]);

  const handleSubmit = useCallback(() => {
    if (prompt.trim().length < 10) {
      toast.error("Please enter at least 10 characters for your story prompt.");
      return;
    }
    setActiveJobId(null);
    createJob.mutate({ prompt: prompt.trim(), durationMinutes: duration, style });
  }, [prompt, duration, style, createJob]);

  const isGenerating = pollingEnabled && jobStatus.data?.status === "processing";
  const isComplete = jobStatus.data?.status === "completed";
  const isFailed = jobStatus.data?.status === "failed";
  const hasActiveJob = activeJobId !== null;

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.82_0.18_196)]" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <NavBar />
        <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4">
          <Film className="h-16 w-16 text-[oklch(0.82_0.18_196)] mb-6 opacity-60" />
          <h2 className="text-2xl font-bold mb-3" style={{ fontFamily: "Syne, sans-serif" }}>Sign in to Create Videos</h2>
          <p className="text-muted-foreground mb-8 max-w-sm">You need to be signed in to generate videos and save your creations.</p>
          <a href={getLoginUrl()}>
            <button className="manifest-btn flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Sign In to Continue
            </button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <NavBar />

      {/* Background glow */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden -z-10">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full bg-[oklch(0.55_0.22_290/0.08)] blur-[100px]" />
      </div>

      <div className="container pt-28 pb-16">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="mb-10">
            <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ fontFamily: "Syne, sans-serif" }}>
              <span className="gradient-text">Create</span> Your Video
            </h1>
            <p className="text-muted-foreground">Describe your story, set your parameters, and let the AI pipeline do the rest.</p>
          </div>

          <div className="grid lg:grid-cols-5 gap-8">
            {/* ── Left: Form ─────────────────────────────────────────────── */}
            <div className="lg:col-span-3 space-y-6">
              {/* Prompt */}
              <div className="glass-card p-6 space-y-3">
                <Label className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Wand2 className="h-4 w-4 text-[oklch(0.82_0.18_196)]" />
                  Your Story Prompt
                </Label>
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe your story in detail... A lone astronaut discovers an ancient alien signal on a distant moon, leading her on a journey that challenges everything humanity believes about its origins..."
                  className="min-h-[160px] bg-white/3 border-white/10 text-foreground placeholder:text-muted-foreground/50 focus:border-[oklch(0.82_0.18_196/0.5)] focus:ring-[oklch(0.82_0.18_196/0.2)] resize-none text-sm leading-relaxed"
                  disabled={isGenerating}
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{prompt.length} characters</span>
                  <span className={prompt.length < 10 ? "text-red-400/70" : "text-[oklch(0.82_0.18_196)/0.7]"}>
                    {prompt.length < 10 ? `${10 - prompt.length} more needed` : "✓ Ready"}
                  </span>
                </div>
              </div>

              {/* Duration */}
              <div className="glass-card p-6 space-y-4">
                <Label className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Clock className="h-4 w-4 text-[oklch(0.82_0.18_196)]" />
                  Duration: <span className="gradient-text">{duration} {duration === 1 ? "minute" : "minutes"}</span>
                </Label>
                <Slider
                  min={1}
                  max={120}
                  step={1}
                  value={[duration]}
                  onValueChange={([v]) => setDuration(v)}
                  disabled={isGenerating}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>1 min</span>
                  <div className="flex gap-3">
                    {[5, 15, 30, 60, 90, 120].map((v) => (
                      <button
                        key={v}
                        onClick={() => setDuration(v)}
                        disabled={isGenerating}
                        className={`px-2 py-0.5 rounded text-xs transition-colors ${
                          duration === v
                            ? "bg-[oklch(0.82_0.18_196/0.2)] text-[oklch(0.82_0.18_196)]"
                            : "hover:text-foreground"
                        }`}
                      >
                        {v}m
                      </button>
                    ))}
                  </div>
                  <span>120 min</span>
                </div>
              </div>

              {/* Style */}
              <div className="glass-card p-6 space-y-3">
                <Label className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Film className="h-4 w-4 text-[oklch(0.82_0.18_196)]" />
                  Visual Style
                </Label>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {STYLES.map((s) => (
                    <button
                      key={s.value}
                      onClick={() => setStyle(s.value)}
                      disabled={isGenerating}
                      className={`p-3 rounded-xl border text-center transition-all duration-200 ${
                        style === s.value
                          ? "border-[oklch(0.82_0.18_196/0.6)] bg-[oklch(0.82_0.18_196/0.08)] text-foreground"
                          : "border-white/8 bg-white/2 text-muted-foreground hover:border-white/20 hover:text-foreground"
                      }`}
                    >
                      <div className="text-xl mb-1">{s.emoji}</div>
                      <div className="text-xs font-medium">{s.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Submit */}
              <button
                onClick={handleSubmit}
                disabled={isGenerating || createJob.isPending || prompt.trim().length < 10}
                className="manifest-btn w-full flex items-center justify-center gap-2 text-base disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {createJob.isPending || isGenerating ? (
                  <><Loader2 className="h-5 w-5 animate-spin" /> Generating...</>
                ) : (
                  <><Wand2 className="h-5 w-5" /> Generate Video</>
                )}
              </button>

              {isComplete && (
                <Link href="/dashboard">
                  <Button variant="outline" className="w-full border-[oklch(0.55_0.22_290/0.4)] text-[oklch(0.55_0.22_290)] hover:bg-[oklch(0.55_0.22_290/0.08)]">
                    View in Dashboard →
                  </Button>
                </Link>
              )}
            </div>

            {/* ── Right: Progress ────────────────────────────────────────── */}
            <div className="lg:col-span-2 space-y-5">
              {/* Status card */}
              <div className="glass-card p-6 space-y-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-foreground" style={{ fontFamily: "Syne, sans-serif" }}>
                    Pipeline Status
                  </h3>
                  {hasActiveJob && (
                    <Badge
                      variant="secondary"
                      className={`text-xs border-0 ${
                        isComplete
                          ? "bg-green-500/15 text-green-400"
                          : isFailed
                          ? "bg-red-500/15 text-red-400"
                          : isGenerating
                          ? "bg-[oklch(0.82_0.18_196/0.15)] text-[oklch(0.82_0.18_196)] animate-pulse"
                          : "bg-white/10 text-muted-foreground"
                      }`}
                    >
                      {isComplete ? "Complete" : isFailed ? "Failed" : isGenerating ? "Processing" : "Queued"}
                    </Badge>
                  )}
                </div>

                {hasActiveJob ? (
                  <>
                    {/* Progress bar */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{jobStatus.data?.currentStage ?? "Initializing"}</span>
                        <span>{Math.round(jobStatus.data?.progress ?? 0)}%</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-white/5 overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{
                            width: `${jobStatus.data?.progress ?? 0}%`,
                            background: isComplete
                              ? "oklch(0.55 0.22 290)"
                              : "linear-gradient(90deg, oklch(0.82 0.18 196), oklch(0.55 0.22 290))",
                          }}
                        />
                      </div>
                    </div>

                    {/* Stage list */}
                    <StageIndicator
                      currentStage={jobStatus.data?.currentStage}
                      progress={jobStatus.data?.progress ?? 0}
                      status={jobStatus.data?.status ?? "queued"}
                    />
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center gap-3">
                    <div className="h-12 w-12 rounded-full bg-white/5 flex items-center justify-center">
                      <Sparkles className="h-6 w-6 text-white/20" />
                    </div>
                    <p className="text-sm text-muted-foreground">Fill in your story details and click Generate to start the AI pipeline.</p>
                  </div>
                )}
              </div>

              {/* Script plan viewer */}
              {jobStatus.data?.scriptPlan && (
                <ScriptViewer scriptPlan={jobStatus.data.scriptPlan} />
              )}

              {/* Completion card */}
              {isComplete && (
                <div className="glass-card p-5 border border-[oklch(0.55_0.22_290/0.3)] space-y-3">
                  <div className="flex items-center gap-2 text-[oklch(0.55_0.22_290)]">
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="font-semibold text-sm">Video Generation Complete!</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Your video has been processed through all 6 pipeline stages. View the full details in your dashboard.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
