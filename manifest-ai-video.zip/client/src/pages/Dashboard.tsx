import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import NavBar from "@/components/NavBar";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle2,
  Clock,
  Film,
  Loader2,
  Plus,
  AlertCircle,
  Sparkles,
  ChevronRight,
  LayoutDashboard,
} from "lucide-react";
import { Link } from "wouter";

const STATUS_CONFIG = {
  queued:     { label: "Queued",     color: "bg-white/10 text-muted-foreground",                           icon: Clock },
  processing: { label: "Processing", color: "bg-[oklch(0.82_0.18_196/0.15)] text-[oklch(0.82_0.18_196)]", icon: Loader2 },
  completed:  { label: "Complete",   color: "bg-green-500/15 text-green-400",                              icon: CheckCircle2 },
  failed:     { label: "Failed",     color: "bg-red-500/15 text-red-400",                                  icon: AlertCircle },
};

const STYLE_EMOJI: Record<string, string> = {
  cinematic:   "🎬",
  documentary: "📽️",
  animation:   "✨",
  "sci-fi":    "🚀",
  fantasy:     "🧙",
  noir:        "🌑",
  thriller:    "⚡",
};

function JobCard({ job }: { job: any }) {
  const cfg = STATUS_CONFIG[job.status as keyof typeof STATUS_CONFIG] ?? STATUS_CONFIG.queued;
  const StatusIcon = cfg.icon;
  const isProcessing = job.status === "processing";

  return (
    <Link href={`/jobs/${job.id}`}>
      <div className="glass-card-hover p-5 cursor-pointer group">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{STYLE_EMOJI[job.style] ?? "🎬"}</span>
            <div>
              <div className="text-xs text-muted-foreground capitalize">{job.style}</div>
              <div className="text-xs text-muted-foreground">{job.durationMinutes} min</div>
            </div>
          </div>
          <Badge variant="secondary" className={`text-xs border-0 shrink-0 flex items-center gap-1 ${cfg.color} ${isProcessing ? "animate-pulse" : ""}`}>
            <StatusIcon className="h-3 w-3" />
            {cfg.label}
          </Badge>
        </div>

        {/* Prompt preview */}
        <p className="text-sm text-foreground/80 line-clamp-2 mb-3 leading-relaxed">
          {job.prompt}
        </p>

        {/* Progress bar (only for active jobs) */}
        {(job.status === "processing" || job.status === "queued") && (
          <div className="space-y-1.5 mb-3">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{job.currentStage ?? "Queued"}</span>
              <span>{Math.round(job.progress ?? 0)}%</span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-white/5 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${job.progress ?? 0}%`,
                  background: "linear-gradient(90deg, oklch(0.82 0.18 196), oklch(0.55 0.22 290))",
                }}
              />
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{new Date(job.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}</span>
          <span className="flex items-center gap-1 text-[oklch(0.82_0.18_196/0.7)] group-hover:text-[oklch(0.82_0.18_196)] transition-colors">
            View details <ChevronRight className="h-3 w-3" />
          </span>
        </div>
      </div>
    </Link>
  );
}

export default function Dashboard() {
  const { isAuthenticated, loading: authLoading } = useAuth();

  const { data: jobs, isLoading, refetch } = trpc.video.list.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: (query) => {
      const data = query.state.data;
      if (!data) return false;
      const hasActive = data.some((j: any) => j.status === "processing" || j.status === "queued");
      return hasActive ? 3000 : false;
    },
  });

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.82_0.18_196)]" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <NavBar />
        <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4">
          <LayoutDashboard className="h-16 w-16 text-[oklch(0.82_0.18_196)] mb-6 opacity-60" />
          <h2 className="text-2xl font-bold mb-3" style={{ fontFamily: "Syne, sans-serif" }}>Sign in to View Your Videos</h2>
          <p className="text-muted-foreground mb-8 max-w-sm">Your video generation history is saved per account.</p>
          <a href={getLoginUrl()}>
            <button className="manifest-btn flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Sign In to Continue
            </button>
          </a>
        </div>
      </div>
    );
  }

  const activeJobs = jobs?.filter((j: any) => j.status === "processing" || j.status === "queued") ?? [];
  const completedJobs = jobs?.filter((j: any) => j.status === "completed") ?? [];
  const failedJobs = jobs?.filter((j: any) => j.status === "failed") ?? [];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <NavBar />

      {/* Background glow */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden -z-10">
        <div className="absolute top-0 right-0 w-[500px] h-[400px] rounded-full bg-[oklch(0.55_0.22_290/0.06)] blur-[120px]" />
      </div>

      <div className="container pt-28 pb-16">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-10">
            <div>
              <h1 className="text-3xl font-bold mb-1" style={{ fontFamily: "Syne, sans-serif" }}>
                <span className="gradient-text">My Videos</span>
              </h1>
              <p className="text-muted-foreground text-sm">
                {jobs?.length ?? 0} total generation{jobs?.length !== 1 ? "s" : ""}
              </p>
            </div>
            <Link href="/generate">
              <button className="manifest-btn flex items-center gap-2 text-sm">
                <Plus className="h-4 w-4" />
                New Video
              </button>
            </Link>
          </div>

          {/* Stats row */}
          {jobs && jobs.length > 0 && (
            <div className="grid grid-cols-3 gap-4 mb-10">
              {[
                { label: "Active", count: activeJobs.length, color: "text-[oklch(0.82_0.18_196)]" },
                { label: "Completed", count: completedJobs.length, color: "text-green-400" },
                { label: "Failed", count: failedJobs.length, color: "text-red-400" },
              ].map((s) => (
                <div key={s.label} className="glass-card p-4 text-center">
                  <div className={`text-2xl font-bold ${s.color}`} style={{ fontFamily: "Syne, sans-serif" }}>{s.count}</div>
                  <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          )}

          {/* Loading */}
          {isLoading && (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.82_0.18_196)]" />
            </div>
          )}

          {/* Empty state */}
          {!isLoading && (!jobs || jobs.length === 0) && (
            <div className="flex flex-col items-center justify-center py-24 text-center">
              <div className="h-20 w-20 rounded-2xl bg-white/3 flex items-center justify-center mb-6">
                <Film className="h-10 w-10 text-white/20" />
              </div>
              <h3 className="text-xl font-semibold mb-2" style={{ fontFamily: "Syne, sans-serif" }}>No videos yet</h3>
              <p className="text-muted-foreground mb-8 max-w-sm">Create your first AI-generated video and it will appear here.</p>
              <Link href="/generate">
                <button className="manifest-btn flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  Create Your First Video
                </button>
              </Link>
            </div>
          )}

          {/* Active jobs */}
          {activeJobs.length > 0 && (
            <div className="mb-8">
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-[oklch(0.82_0.18_196)]" />
                Active ({activeJobs.length})
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {activeJobs.map((job: any) => <JobCard key={job.id} job={job} />)}
              </div>
            </div>
          )}

          {/* Completed jobs */}
          {completedJobs.length > 0 && (
            <div className="mb-8">
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
                <CheckCircle2 className="h-3.5 w-3.5 text-green-400" />
                Completed ({completedJobs.length})
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {completedJobs.map((job: any) => <JobCard key={job.id} job={job} />)}
              </div>
            </div>
          )}

          {/* Failed jobs */}
          {failedJobs.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4 flex items-center gap-2">
                <AlertCircle className="h-3.5 w-3.5 text-red-400" />
                Failed ({failedJobs.length})
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {failedJobs.map((job: any) => <JobCard key={job.id} job={job} />)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
