import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import NavBar from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import {
  Clock,
  Film,
  Infinity,
  Sparkles,
  Wand2,
  ChevronRight,
  Zap,
  Shield,
  Star,
} from "lucide-react";
import { Link } from "wouter";

const FEATURES = [
  {
    icon: Infinity,
    title: "Unlimited Length",
    desc: "Generate videos of any duration — from a short clip to a full two-hour cinematic experience.",
    color: "from-[oklch(0.82_0.18_196)] to-[oklch(0.70_0.20_210)]",
  },
  {
    icon: Sparkles,
    title: "Multi-Agent AI",
    desc: "Specialized AI agents collaborate across script writing, shot design, and audio production.",
    color: "from-[oklch(0.55_0.22_290)] to-[oklch(0.65_0.22_310)]",
  },
  {
    icon: Film,
    title: "Cinematic Quality",
    desc: "Studio-grade visuals with professional color grading, dynamic shots, and immersive audio.",
    color: "from-[oklch(0.70_0.18_140)] to-[oklch(0.75_0.15_160)]",
  },
  {
    icon: Clock,
    title: "Up to 2-Hour Videos",
    desc: "No time limits. Tell your full story without compromise — up to 120 minutes of generated content.",
    color: "from-[oklch(0.70_0.20_50)] to-[oklch(0.65_0.22_30)]",
  },
];

const PIPELINE_STAGES = ["Analyzing", "Scripting", "Designing", "Generating", "Audio", "Finalizing"];

const STYLES = [
  { name: "Cinematic", emoji: "🎬" },
  { name: "Documentary", emoji: "📽️" },
  { name: "Animation", emoji: "✨" },
  { name: "Sci-Fi", emoji: "🚀" },
  { name: "Fantasy", emoji: "🧙" },
  { name: "Noir", emoji: "🌑" },
];

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <NavBar />

      {/* ── Hero ──────────────────────────────────────────────────────────── */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        {/* Background glow orbs */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[600px] rounded-full bg-[oklch(0.55_0.22_290/0.12)] blur-[120px]" />
          <div className="absolute top-1/3 -left-32 w-[500px] h-[400px] rounded-full bg-[oklch(0.82_0.18_196/0.07)] blur-[100px]" />
          <div className="absolute top-1/2 -right-32 w-[400px] h-[400px] rounded-full bg-[oklch(0.55_0.22_290/0.08)] blur-[100px]" />
        </div>

        <div className="container relative text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 rounded-full border border-[oklch(0.82_0.18_196/0.25)] bg-[oklch(0.82_0.18_196/0.06)] px-4 py-1.5 text-sm text-[oklch(0.82_0.18_196)] mb-8">
            <Zap className="h-3.5 w-3.5" />
            Powered by Multi-Agent AI Pipeline
          </div>

          {/* Headline */}
          <h1
            className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.08] mb-6"
            style={{ fontFamily: "Syne, sans-serif" }}
          >
            <span className="gradient-text">Manifest Your Vision</span>
            <br />
            <span className="text-foreground/90">Into Infinite Video</span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Transform any story into a cinematic masterpiece. No time limits. No compromises.
            Just describe your vision and watch it come to life.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/generate">
              <button className="manifest-btn flex items-center gap-2 text-base">
                <Wand2 className="h-5 w-5" />
                Start Creating
                <ChevronRight className="h-4 w-4" />
              </button>
            </Link>
            {!isAuthenticated && (
              <a href={getLoginUrl()}>
                <Button variant="outline" size="lg" className="border-white/15 text-foreground/80 hover:border-[oklch(0.82_0.18_196/0.4)] hover:text-foreground bg-transparent">
                  Sign In Free
                </Button>
              </a>
            )}
          </div>

          {/* Stage pipeline preview */}
          <div className="mt-16 flex flex-wrap items-center justify-center gap-2">
            {PIPELINE_STAGES.map((stage, i) => (
              <div key={stage} className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 rounded-full border border-white/8 bg-white/3 px-3 py-1 text-xs text-muted-foreground">
                  <div className={`h-1.5 w-1.5 rounded-full ${i === 3 ? "bg-[oklch(0.82_0.18_196)] pulse-glow" : i < 3 ? "bg-[oklch(0.55_0.22_290)]" : "bg-white/20"}`} />
                  {stage}
                </div>
                {i < PIPELINE_STAGES.length - 1 && (
                  <ChevronRight className="h-3 w-3 text-white/15" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Feature Cards ─────────────────────────────────────────────────── */}
      <section className="py-20 border-t border-white/5">
        <div className="container">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ fontFamily: "Syne, sans-serif" }}>
              Built for <span className="gradient-text">Cinematic Storytelling</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Every feature is designed to give your story the production quality it deserves.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {FEATURES.map((f) => (
              <div key={f.title} className="glass-card-hover p-6 flex flex-col gap-4">
                <div className={`h-11 w-11 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center shadow-lg`}>
                  <f.icon className="h-5 w-5 text-black" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1.5" style={{ fontFamily: "Syne, sans-serif" }}>{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Visual Styles ─────────────────────────────────────────────────── */}
      <section className="py-20 border-t border-white/5">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3" style={{ fontFamily: "Syne, sans-serif" }}>
              Six Distinct <span className="gradient-text">Visual Styles</span>
            </h2>
            <p className="text-muted-foreground">Choose the aesthetic that matches your story's soul.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {STYLES.map((s) => (
              <div key={s.name} className="glass-card-hover p-5 text-center cursor-pointer">
                <div className="text-3xl mb-2">{s.emoji}</div>
                <div className="text-sm font-medium text-foreground/80">{s.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ──────────────────────────────────────────────────── */}
      <section className="py-20 border-t border-white/5">
        <div className="container">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold mb-3" style={{ fontFamily: "Syne, sans-serif" }}>
              How <span className="gradient-text">It Works</span>
            </h2>
            <p className="text-muted-foreground">Three steps from story to screen.</p>
          </div>
          <div className="grid sm:grid-cols-3 gap-8 max-w-3xl mx-auto">
            {[
              { step: "01", title: "Describe Your Story", desc: "Write your story prompt — as brief or detailed as you like. Set the duration and visual style." },
              { step: "02", title: "AI Pipeline Runs", desc: "Six specialized agents analyze, script, design, generate, score, and finalize your video." },
              { step: "03", title: "Download & Share", desc: "Your cinematic video is ready. Download it in full quality or share directly from the dashboard." },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="text-5xl font-extrabold gradient-text mb-4" style={{ fontFamily: "Syne, sans-serif" }}>{item.step}</div>
                <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA Banner ────────────────────────────────────────────────────── */}
      <section className="py-24 border-t border-white/5">
        <div className="container text-center">
          <div className="relative inline-block w-full max-w-2xl mx-auto">
            <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.82_0.18_196/0.15)] to-[oklch(0.55_0.22_290/0.15)] blur-3xl rounded-3xl" />
            <div className="relative glass-card p-12">
              <Star className="h-8 w-8 text-[oklch(0.82_0.18_196)] mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-4" style={{ fontFamily: "Syne, sans-serif" }}>
                Ready to <span className="gradient-text">Manifest?</span>
              </h2>
              <p className="text-muted-foreground mb-8">
                Join creators turning their stories into cinematic experiences. Start free, no credit card required.
              </p>
              <Link href="/generate">
                <button className="manifest-btn flex items-center gap-2 mx-auto text-base">
                  <Wand2 className="h-5 w-5" />
                  Create Your First Video
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ────────────────────────────────────────────────────────── */}
      <footer className="border-t border-white/5 py-8">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Film className="h-4 w-4 text-[oklch(0.82_0.18_196)]" />
            <span style={{ fontFamily: "Syne, sans-serif" }}>Manifest AI Video</span>
          </div>
          <div className="flex items-center gap-1">
            <Shield className="h-3.5 w-3.5" />
            <span>Your stories are private and secure.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
