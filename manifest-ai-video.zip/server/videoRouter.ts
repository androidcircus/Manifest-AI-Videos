import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "./_core/trpc";
import {
  createVideoJob,
  getVideoJobById,
  getVideoJobsByUserId,
  updateVideoJob,
} from "./db";
import { invokeLLM } from "./_core/llm";

// ─── Stage pipeline definition ────────────────────────────────────────────────
// Each stage has a minimum elapsed time (seconds) before it can advance.
// This is DB-driven: on every poll, we check elapsed time and advance if ready.

const STAGES = [
  { name: "Analyzing",  progress: 10, minSeconds: 3  },
  { name: "Scripting",  progress: 25, minSeconds: 8  },
  { name: "Designing",  progress: 42, minSeconds: 14 },
  { name: "Generating", progress: 65, minSeconds: 22 },
  { name: "Audio",      progress: 85, minSeconds: 30 },
  { name: "Finalizing", progress: 97, minSeconds: 36 },
] as const;

type StageName = (typeof STAGES)[number]["name"];

// ─── LLM: generate script + shot plan ────────────────────────────────────────

async function generateScriptPlan(
  prompt: string,
  durationMinutes: number,
  style: string
): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are a professional cinematic screenwriter and director. 
Given a story prompt, generate a structured video script and shot plan in JSON format.
The output must be valid JSON with this exact structure:
{
  "title": "string",
  "logline": "string (one sentence summary)",
  "acts": [
    {
      "actNumber": 1,
      "title": "string",
      "duration": "string (e.g. '10 min')",
      "scenes": [
        {
          "sceneNumber": 1,
          "location": "string",
          "timeOfDay": "string",
          "description": "string",
          "shotType": "string (e.g. 'Wide establishing shot')",
          "dialogue": "string or null",
          "mood": "string",
          "visualNotes": "string"
        }
      ]
    }
  ],
  "productionNotes": {
    "style": "string",
    "colorGrading": "string",
    "musicMood": "string",
    "pacing": "string"
  }
}`,
        },
        {
          role: "user",
          content: `Create a ${durationMinutes}-minute ${style} video script for the following story:\n\n${prompt}\n\nGenerate a detailed, professional script with multiple acts and scenes proportional to the ${durationMinutes}-minute runtime.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const rawContent = response?.choices?.[0]?.message?.content ?? "{}";
    const content = typeof rawContent === "string" ? rawContent : JSON.stringify(rawContent);
    JSON.parse(content); // validate
    return content;
  } catch (err) {
    console.error("[LLM] Script generation failed:", err);
    return JSON.stringify({
      title: "Untitled Production",
      logline: prompt.slice(0, 120),
      acts: [
        {
          actNumber: 1,
          title: "Act One",
          duration: `${durationMinutes} min`,
          scenes: [
            {
              sceneNumber: 1,
              location: "Opening Scene",
              timeOfDay: "Day",
              description: prompt.slice(0, 200),
              shotType: "Wide establishing shot",
              dialogue: null,
              mood: style,
              visualNotes: `${style} visual treatment`,
            },
          ],
        },
      ],
      productionNotes: {
        style,
        colorGrading: "Cinematic LUT",
        musicMood: "Orchestral",
        pacing: "Moderate",
      },
    });
  }
}

// ─── DB-driven stage advancement ──────────────────────────────────────────────
// Called on every getStatus poll. Checks elapsed time and advances stage if ready.
// Safe for serverless: no background process needed — state lives in the DB.

async function advanceStageIfReady(jobId: number): Promise<void> {
  const job = await getVideoJobById(jobId);
  if (!job || job.status === "completed" || job.status === "failed") return;

  const elapsedSeconds = (Date.now() - new Date(job.updatedAt).getTime()) / 1000;
  const currentStageIdx = STAGES.findIndex((s) => s.name === job.currentStage);

  if (currentStageIdx === -1) return;

  const currentStageDef = STAGES[currentStageIdx];
  const nextStageDef = STAGES[currentStageIdx + 1];

  // If we've been in this stage long enough, advance
  if (elapsedSeconds >= currentStageDef.minSeconds) {
    if (nextStageDef) {
      // Advance to next stage
      await updateVideoJob(jobId, {
        status: "processing",
        progress: nextStageDef.progress,
        currentStage: nextStageDef.name,
      });
    } else {
      // All stages done — mark complete
      await updateVideoJob(jobId, {
        status: "completed",
        progress: 100,
        currentStage: "Finalizing",
        completedAt: new Date(),
        result: JSON.stringify({
          message: "Video generation complete",
          jobId,
          generatedAt: new Date().toISOString(),
        }),
      });
    }
  }
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const videoRouter = router({
  /** Create a new video generation job */
  create: protectedProcedure
    .input(
      z.object({
        prompt: z.string().min(10, "Prompt must be at least 10 characters").max(5000),
        durationMinutes: z.number().int().min(1).max(120),
        style: z.enum(["cinematic", "documentary", "animation", "noir", "sci-fi", "fantasy", "thriller"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // 1. Create the job record in DB
      const jobId = await createVideoJob({
        userId: ctx.user.id,
        prompt: input.prompt,
        durationMinutes: input.durationMinutes,
        style: input.style,
        status: "processing",
        progress: 5,
        currentStage: "Analyzing",
      });

      // 2. Generate script plan synchronously (LLM call, ~2-5s)
      //    We do this inline so the script is ready when the user polls.
      //    On serverless, this request stays alive until the LLM responds.
      generateScriptPlan(input.prompt, input.durationMinutes, input.style)
        .then((scriptPlan) =>
          updateVideoJob(jobId, {
            scriptPlan,
            progress: STAGES[0].progress,
            currentStage: STAGES[0].name,
          })
        )
        .catch((err) => {
          console.error(`[VideoJob ${jobId}] Script generation error:`, err);
          updateVideoJob(jobId, {
            status: "failed",
            errorMessage: err instanceof Error ? err.message : "Script generation failed",
          }).catch(() => {});
        });

      return { jobId, status: "processing" as const };
    }),

  /** Get status of a single job — also advances stage if ready (DB-driven) */
  getStatus: protectedProcedure
    .input(z.object({ jobId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const job = await getVideoJobById(input.jobId);
      if (!job) throw new TRPCError({ code: "NOT_FOUND", message: "Job not found" });
      if (job.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

      // Advance stage if enough time has elapsed (serverless-safe)
      if (job.status === "processing") {
        await advanceStageIfReady(input.jobId);
        // Re-fetch after potential advancement
        const updated = await getVideoJobById(input.jobId);
        if (updated) {
          return {
            id: updated.id,
            prompt: updated.prompt,
            durationMinutes: updated.durationMinutes,
            style: updated.style,
            status: updated.status,
            progress: updated.progress,
            currentStage: updated.currentStage,
            scriptPlan: updated.scriptPlan,
            result: updated.result,
            errorMessage: updated.errorMessage,
            createdAt: updated.createdAt,
            completedAt: updated.completedAt,
          };
        }
      }

      return {
        id: job.id,
        prompt: job.prompt,
        durationMinutes: job.durationMinutes,
        style: job.style,
        status: job.status,
        progress: job.progress,
        currentStage: job.currentStage,
        scriptPlan: job.scriptPlan,
        result: job.result,
        errorMessage: job.errorMessage,
        createdAt: job.createdAt,
        completedAt: job.completedAt,
      };
    }),

  /** List all jobs for the current user */
  list: protectedProcedure.query(async ({ ctx }) => {
    const jobs = await getVideoJobsByUserId(ctx.user.id);
    return jobs.map((j) => ({
      id: j.id,
      prompt: j.prompt,
      durationMinutes: j.durationMinutes,
      style: j.style,
      status: j.status,
      progress: j.progress,
      currentStage: j.currentStage,
      createdAt: j.createdAt,
      completedAt: j.completedAt,
    }));
  }),

  /** Get full script plan for a job */
  getScript: protectedProcedure
    .input(z.object({ jobId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const job = await getVideoJobById(input.jobId);
      if (!job) throw new TRPCError({ code: "NOT_FOUND" });
      if (job.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      return { scriptPlan: job.scriptPlan };
    }),
});
