import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock the database helpers ────────────────────────────────────────────────
vi.mock("./db", () => ({
  createVideoJob: vi.fn().mockResolvedValue(42),
  getVideoJobById: vi.fn().mockResolvedValue({
    id: 42,
    userId: 1,
    prompt: "A lone astronaut discovers an alien signal on a distant moon.",
    durationMinutes: 10,
    style: "cinematic",
    status: "processing",
    progress: 25,
    currentStage: "Scripting",
    scriptPlan: JSON.stringify({ title: "Test", logline: "Test logline", acts: [], productionNotes: {} }),
    result: null,
    errorMessage: null,
    createdAt: new Date("2026-01-01T00:00:00Z"),
    updatedAt: new Date("2026-01-01T00:00:00Z"),
    completedAt: null,
  }),
  getVideoJobsByUserId: vi.fn().mockResolvedValue([
    {
      id: 42,
      userId: 1,
      prompt: "A lone astronaut discovers an alien signal on a distant moon.",
      durationMinutes: 10,
      style: "cinematic",
      status: "processing",
      progress: 25,
      currentStage: "Scripting",
      createdAt: new Date("2026-01-01T00:00:00Z"),
      completedAt: null,
    },
  ]),
  updateVideoJob: vi.fn().mockResolvedValue(undefined),
}));

// ─── Mock LLM to avoid real API calls ────────────────────────────────────────
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [
      {
        message: {
          content: JSON.stringify({
            title: "Test Production",
            logline: "A test story",
            acts: [],
            productionNotes: { style: "cinematic", colorGrading: "LUT", musicMood: "Orchestral", pacing: "Moderate" },
          }),
        },
      },
    ],
  }),
}));

// ─── Auth context factory ─────────────────────────────────────────────────────
function createAuthContext(userId = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: "test-user-open-id",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("video.create", () => {
  it("creates a new video job and returns jobId", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.video.create({
      prompt: "A lone astronaut discovers an alien signal on a distant moon.",
      durationMinutes: 10,
      style: "cinematic",
    });

    expect(result).toMatchObject({ jobId: 42, status: "processing" });
  });

  it("rejects prompts shorter than 10 characters", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.video.create({ prompt: "Short", durationMinutes: 5, style: "cinematic" })
    ).rejects.toThrow();
  });

  it("rejects duration > 120 minutes", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.video.create({
        prompt: "A valid story prompt for testing purposes.",
        durationMinutes: 121,
        style: "cinematic",
      })
    ).rejects.toThrow();
  });
});

describe("video.getStatus", () => {
  it("returns job status for the owner", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.video.getStatus({ jobId: 42 });

    expect(result).toMatchObject({
      id: 42,
      status: "processing",
      progress: 25,
      currentStage: "Scripting",
    });
  });

  it("throws FORBIDDEN when a different user requests the job", async () => {
    const ctx = createAuthContext(99); // different user
    const caller = appRouter.createCaller(ctx);

    await expect(caller.video.getStatus({ jobId: 42 })).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });
});

describe("video.list", () => {
  it("returns all jobs for the authenticated user", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.video.list();

    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBe(1);
    expect(result[0]).toMatchObject({ id: 42, style: "cinematic" });
  });
});
