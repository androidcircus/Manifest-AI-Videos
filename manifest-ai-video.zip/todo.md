# Manifest AI Video — TODO

## Database & Backend
- [x] Add videoJobs table to drizzle/schema.ts with fields: prompt, duration, style, status, progress, currentStage, scriptPlan, result, userId
- [x] Run migration and apply SQL via webdev_execute_sql
- [x] Add db helpers in server/db.ts for videoJobs CRUD
- [x] Add tRPC router: video.create — creates a new job, triggers LLM script generation
- [x] Add tRPC router: video.getStatus — polls a single job by id
- [x] Add tRPC router: video.list — returns all jobs for current user
- [x] Add tRPC router: video.getScript — returns full script plan for a job
- [x] LLM integration: generate script + shot plan from user prompt
- [x] Background stage pipeline simulation (Analyzing → Scripting → Designing → Generating → Audio → Finalizing)

## Frontend
- [x] Global dark cinematic theme in index.css (deep black bg, cyan/violet accent, cinematic font)
- [x] Update client/index.html with Google Fonts (Inter + Syne)
- [x] Cinematic landing page (hero, feature cards, visual styles, how it works, CTA)
- [x] Video generation form (prompt textarea, duration 1–120 min slider, style selector)
- [x] Real-time progress tracker (stage pipeline: Analyzing → Scripting → Designing → Generating → Audio → Finalizing)
- [x] Job history dashboard page with stats, active/completed/failed sections
- [x] Job detail page with full script plan viewer and stage descriptions
- [x] Navigation header with auth (login/logout, user avatar dropdown)
- [x] Route setup in App.tsx (/generate, /dashboard, /jobs/:id)
- [x] Responsive design and polish

## Tests
- [x] Vitest: video.create procedure
- [x] Vitest: video.getStatus procedure (owner access + forbidden)
- [x] Vitest: video.list procedure

## Follow-Up Features
- [ ] Add retry flow: video.retry procedure + Retry button on JobDetail page
- [ ] Add email notifications: notifyOwner on job completion + completion email UI
- [ ] Add public gallery: isPublic field, video.togglePublic procedure, Gallery page
- [ ] Add advanced filtering: status/date/style filters on Dashboard
