CREATE TABLE `video_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`prompt` text NOT NULL,
	`durationMinutes` int NOT NULL DEFAULT 5,
	`style` varchar(64) NOT NULL DEFAULT 'cinematic',
	`status` enum('queued','processing','completed','failed') NOT NULL DEFAULT 'queued',
	`progress` float NOT NULL DEFAULT 0,
	`currentStage` varchar(64) DEFAULT 'Analyzing',
	`scriptPlan` text,
	`result` text,
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`completedAt` timestamp,
	CONSTRAINT `video_jobs_id` PRIMARY KEY(`id`)
);
